Strings = {
    -- Text UI strings --
    clothing_menu = '[E] - Changer de vêtements',
    clothingroom_menu = '[E] Ouvrir le vestiaire',
    barber_menu = '[E] - Changer de cheveux/visage',
    tattoo_menu = '[E] - Changer de tatouage',

    -- Notifications --
    success = 'Success',
    success_desc = 'You have successfully paid $%s for a new look!',

    no_funds = 'Lacking funds',
    no_funds_desc = 'You do not have enough funds in the bank for this',

    -- Menus --

    -- Main clothing shop menu
    clothing_shop_title = 'Menu du Magasin',
    clothingroom_title = 'Ouvrir le vestiaire',
    change_clothing_title = 'Changer de vêtements',
    change_clothing_desc = 'Parcourir les vêtements disponibles',
    browse_outfits_title = 'Parcourir les tenues',
    browse_outfits_desc = 'Parcourir les tenues enregistrées',
    save_outfit_title = 'Enregistrer la tenue',
    save_outfit_info = 'Nom de la tenue',
    save_outfit_desc = 'Enregistrer la tenue actuelle',
    delete_outfit_title = 'Supprimer les tenues',
    delete_outfit_desc = 'Supprimer une tenue enregistrée',

    -- Browse/Delete outfits & Wardrobe
    wardrobe_title = 'Garde-robe',
    delete_outfits_title = 'Supprimer les tenues',
    go_back_title = '< Retour',
    go_back_desc = 'Aucune tenue enregistrée!',

    -- Other
    skin_command_help = 'Change Skin',
    skin_command_arg_help = 'Player ID'
}
